# SETUP.md — Zero to Claude Code on polyroute

This is your walkthrough from an empty directory to Claude Code iterating on the repo. Follow it once, then delete it.

---

## Prerequisites (5 min check)

Open your terminal and check:

```bash
node --version     # need 18 or newer
python --version   # need 3.10 or newer
git --version      # any recent version
docker --version   # for OTP2 later (not required today)
```

If Node is below 18, install via `nvm`:
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
# reopen terminal
nvm install 22
nvm use 22
```

Do **not** use `sudo` to install anything in this guide.

---

## Step 1 — Install Claude Code (2 min)

### macOS / Linux (recommended)

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

This is the native installer — no Node dependency, auto-updates in the background.

### Windows

Two options:

**Option A (recommended): WSL2 with Ubuntu.** Cleaner because this project uses Docker and shell scripts. If you already have WSL, open your Ubuntu terminal and run the Linux curl command above.

**Option B: Native Windows.** Install Git for Windows first, then from PowerShell:
```powershell
irm https://claude.ai/install.ps1 | iex
```

### npm fallback (any OS)

```bash
npm install -g @anthropic-ai/claude-code
```

### Verify

```bash
claude --version
claude doctor
```

`claude doctor` checks auth, PATH, and config. Fix any issues it reports before continuing.

---

## Step 2 — Create the GitHub repo (2 min)

1. Go to https://github.com/new
2. **Repository name:** `polyroute`
3. **Description:** `Agentic multi-modal journey planning that actually mixes modes. Pareto-optimal routes with natural-language tradeoff explanations.`
4. **Public**
5. **Do NOT** initialize with README, .gitignore, or license. We already have all three.
6. Click **Create repository**.

Keep the browser tab open — you'll need the URL in step 4.

---

## Step 3 — Get the scaffold onto your machine (3 min)

Download `polyroute.tar.gz` (the archive from our claude.ai conversation).

```bash
# Pick a sensible location
cd ~/code   # or ~/Projects, or wherever you keep repos
mkdir -p polyroute-workspace
cd polyroute-workspace

# Extract
tar xzf ~/Downloads/polyroute.tar.gz

# You now have ~/code/polyroute-workspace/polyroute/
cd polyroute
ls -la
```

You should see `README.md`, `pyproject.toml`, `polyroute/`, `tests/`, `web/`, `docker/`, `docs/`, etc.

---

## Step 4 — Drop in the handoff files (2 min)

From this package, copy `CLAUDE.md` and `FIRST_SESSION.md` into the repo root:

```bash
# Assuming you saved the handoff pack to ~/Downloads/handoff/
cp ~/Downloads/handoff/CLAUDE.md ./CLAUDE.md
cp ~/Downloads/handoff/FIRST_SESSION.md ./FIRST_SESSION.md

ls -la CLAUDE.md FIRST_SESSION.md
```

Both should be present at the repo root.

---

## Step 5 — Wire the repo to GitHub (1 min)

```bash
git init
git branch -M main
git remote add origin https://github.com/KIRTIRAJ4327/polyroute.git
git status
```

Do not commit yet. Claude Code should make the first commit — it's a good checkpoint that it's wired up correctly.

---

## Step 6 — Start Claude Code (1 min)

From inside the repo:

```bash
claude
```

On first run, it opens a browser for OAuth. Sign in with the Anthropic account that has your Claude Pro / Max / Team subscription. Grant the permissions it asks for.

You're now in a Claude Code session with full read/write on this directory.

---

## Step 7 — The opening prompt

Paste this verbatim as your first message to Claude Code:

> Read `FIRST_SESSION.md` in the repo root and execute the steps it lays out, in order. That file references `CLAUDE.md`, which you should also read in full — `CLAUDE.md` is our permanent working memory for this project and has all the research, strategy, architecture, and constraints. Do not skip reading. Confirm understanding before you start executing.

Claude Code will:
1. Read both files
2. Summarize understanding back to you
3. Run `pytest` and the demo to verify the scaffold
4. Make the initial commit and push
5. Set up the GitHub repo (topics, description, milestone, v0.1.0 issues)
6. Ask you which track to start first

---

## Step 8 — Confirm the repo is live

After Claude Code pushes the initial commit, visit https://github.com/KIRTIRAJ4327/polyroute in your browser.

You should see:
- README rendering with the Fountainhead → YYZ demo output in the intro
- 9 passing tests (if CI gets set up as part of the first session)
- The repo description and topics populated
- v0.1.0 milestone with scaffolded issues

Screenshot this — it's a share-worthy moment for LinkedIn.

---

## Step 9 — Optional but recommended: LinkedIn post

Once the repo is public and clean, post something like:

> Started polyroute this weekend — an open-source agentic multi-modal journey planner. The wedge is airport access in the GTA (think: Mississauga to YYZ optimized across mixed Uber+transit combos that Google Maps never surfaces).
>
> Built on OpenTripPlanner 2 for the routing substrate, with a Pareto frontier over time/cost/effort/reliability and LLM-generated tradeoff explanations as the differentiator.
>
> It's deliberately not a consumer app — the MaaS consumer graveyard is well documented (Citymapper, Whim, Trafi consumer). The thesis is the reasoning layer as a B2B2C play for transit agencies and airports.
>
> Early days. Scaffold up, airport-access demo working end-to-end, looking for Pearson commuters who want to try it and tell me what's broken.
>
> github.com/KIRTIRAJ4327/polyroute

Adjust the voice to yours — that's a draft, not a script.

---

## When you get stuck

### `claude` command not found
Close and reopen your terminal. If still missing:
```bash
which claude
# if nothing returned, check install location is on PATH
echo $PATH
```
For native installer, binary lives in `~/.local/bin`. Add it to PATH via your shell config (`~/.zshrc` or `~/.bashrc`).

### Auth fails on first run
`claude doctor` will tell you what's wrong. Most common: firewall blocking OAuth redirect, or a stale token from a previous install (delete `~/.claude/` and retry).

### `pytest` fails
Run `pip install -e ".[dev]"` first. The `[dev]` extra installs pytest.

### Server won't start
Port 8000 already in use. Run on a different port:
```bash
uvicorn polyroute.api.server:app --reload --port 8765
```

### Docker / OTP2 problems later
Don't worry about OTP2 in the first session. The mock adapter gives you everything you need to see the pipeline work. OTP2 is the first issue Claude Code will take on once the scaffold is confirmed.

---

## After this file

Delete it:
```bash
rm SETUP.md FIRST_SESSION.md   # optional: mv to docs/archive/
```

From now on, `CLAUDE.md` is the permanent context. Every Claude Code session will read it. Update it whenever you make a meaningful decision — new research, scope changes, pivot signals, partnerships.

Good luck. Go build.
