# polyroute handoff pack

This bundle contains everything Claude Code needs to pick up the polyroute project and continue building it without re-asking any questions. Use it once, then delete the one-time files.

## What's in here

| File | Purpose | Lifespan |
|---|---|---|
| `SETUP.md` | Zero-to-running walkthrough for you. Install Claude Code, create the GitHub repo, drop in the scaffold, start the first session. | One-time. Delete after setup. |
| `FIRST_SESSION.md` | The instructions you paste into Claude Code on its first run in this repo. | One-time. Claude Code archives it after reading. |
| `CLAUDE.md` | Permanent working memory for Claude Code. The single most important file. Contains research, strategy, architecture, conventions, roadmap, and owner context. | Lives forever in the repo root. Update it as decisions are made. |
| `research.md` | Full research document from the claude.ai conversation — goes into `docs/research.md` in the repo. Referenced by `README.md`. | Permanent. Re-read before major pivots. |

## The order of operations

1. Open `SETUP.md` and follow it top to bottom
2. When it tells you to drop files into the repo, copy `CLAUDE.md` to the repo root and `research.md` to `docs/research.md`
3. Start Claude Code with the opening prompt from `SETUP.md` Step 7
4. Claude Code will read `FIRST_SESSION.md` and `CLAUDE.md`, execute the checklist, and check in with you

## What Claude Code will know after reading these

- Who you are, what you do at TCS, your background in agentic AI and LangGraph
- The complete market research — why Citymapper, Whim, Trafi consumer all failed, why rideshare APIs block honest price comparison, why B2B2C is the only viable path
- The four-layer architecture and what's already built
- The three wedges (airport, newcomer, corporate) and why airport-access is first
- The 90-day validation plan and what success looks like at week 12
- The Canadian non-dilutive funding stack (SR&ED, IRAP) and why it matters more than equity
- Strategic non-negotiables: open source, Toronto-only v0.x, no native apps, no live rideshare pricing, no LangGraph in the core path, no consumer subscription
- How you prefer to communicate (direct, casual, accuracy over confidence, 6-10 hrs/week cadence)

## Maintaining the memory

`CLAUDE.md` is a living document. Every major decision, pivot, research update, or scope change should be committed to it. Good rule of thumb: if a future Claude Code session would need to know about the decision to do its job, it belongs in `CLAUDE.md`.

Don't let it bloat. Prune outdated sections when they're superseded. If it grows past ~500 lines, split subsections into files under `docs/` and reference them from `CLAUDE.md`.

## Troubleshooting

If Claude Code seems confused about the project or asks basic questions already answered in `CLAUDE.md`, the most likely causes are:
1. It didn't actually read the file — ask it to read `CLAUDE.md` in full and summarize
2. The file is out of date — update it with whatever recent decision is missing
3. You're in the wrong directory — Claude Code only auto-loads `CLAUDE.md` from the current working directory

---

Good luck. Go build.
